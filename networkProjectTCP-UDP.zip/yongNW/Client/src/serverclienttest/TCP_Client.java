package serverclienttest;

import java.io.*;
import java.net.*;

public class TCP_Client {

    public void Client(String message, String ip, int port) throws Exception {

        try {
            //create socket
            Socket clientSocket = new Socket(ip, port);
            clientSocket.setSoTimeout(3000);
            
            //send
            DataOutputStream writeToServer = new DataOutputStream(clientSocket.getOutputStream());
            writeToServer.writeBytes(message + '\n');
            
            //receive 
            BufferedReader readFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            CLIENT_GUI.jTextArea1.setText("\nSend Success\nThe Message From SERVER : " + "\"" + readFromServer.readLine() + "\"" + "\n");

            clientSocket.close();
        } catch (IOException e) {
            CLIENT_GUI.jTextArea1.append("\nTimeout\n");

        }

    }
}
