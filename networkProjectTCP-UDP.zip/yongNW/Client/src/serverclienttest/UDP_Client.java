/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverclienttest;

import java.io.*;
import java.net.*;

public class UDP_Client {

    public void Client(String message, String ip, int port) throws Exception {

        try {
            //create socket 
            DatagramSocket clientSocket = new DatagramSocket();
            clientSocket.setSoTimeout(3000);
            

            //create data ip port and send packet 
            byte[] sendData = new byte[1024];
            sendData = message.getBytes();
            InetAddress makeIP = InetAddress.getByName(ip);
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, makeIP, port);
            clientSocket.send(sendPacket);
            
            
            //receive data
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            clientSocket.receive(receivePacket);
            String readString = new String(receivePacket.getData());

            CLIENT_GUI.jTextArea1.append("\nSend success\nThe Message From SERVER: " + readString + "\n");

            clientSocket.close();
        } catch (IOException e) {
            CLIENT_GUI.jTextArea1.append("\nTimeout\n");

        }

    }

}
