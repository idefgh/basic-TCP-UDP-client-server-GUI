/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package network;

import java.io.*;
import java.net.*;
import javax.swing.SwingWorker;

public class UDPserver extends SwingWorker<Void, Void> {

    int port;
    DatagramSocket serverSocket;

    public void Server(int port) throws IOException {
        this.port = port;
    }

    @Override
    public Void doInBackground() throws Exception {

        serverSocket = new DatagramSocket(port);
        
        byte[] sendData = new byte[1024];

        while (true) {
            //receive
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            serverSocket.receive(receivePacket);

            String readString = new String(receivePacket.getData());
            Server_GUI.jTextArea1.append("\nThe Message From Client : " + "\"" + readString + "\"");
            
            //send 
            InetAddress makeIP = receivePacket.getAddress();
            int port = receivePacket.getPort();
            String writeString = readString.toUpperCase();
            sendData = writeString.getBytes();

            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, makeIP, port);
            serverSocket.send(sendPacket);

        }

    }

    public void closed() throws IOException {
        this.serverSocket.close();
    }
}
