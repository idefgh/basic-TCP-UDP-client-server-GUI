package network;

import java.io.*;
import java.net.*;
import javax.swing.SwingWorker;

public class TCPserver extends SwingWorker<Void, Void> {

    String readString;
    String upperCaseString;
    int port;
    ServerSocket openSocket;
    Socket connectSocket;

    public void Server(int port) throws IOException {
        this.port = port;
    }

    @Override
    public Void doInBackground() throws Exception {

        openSocket = new ServerSocket(port);
        while (true) {
            //create socket and check
            connectSocket = openSocket.accept();

            //receive
            BufferedReader readFromClient = new BufferedReader(new InputStreamReader(connectSocket.getInputStream()));
            readString = readFromClient.readLine();
            Server_GUI.jTextArea1.append("\nMessage From Client : " + "\"" + readString + "\"");

            //convert to uppercase
            upperCaseString = readString.toUpperCase() + '\n';

            //send back
            DataOutputStream writeToClient = new DataOutputStream(connectSocket.getOutputStream());
            writeToClient.writeBytes(upperCaseString);

        }

    }

    public void closed() throws IOException {
        this.openSocket.close();
    }

}
